---
layout: default
title: Resume
permalink: /resume
---

# Resume

**Option A (recommended):** Upload a PDF to `assets/Aditya_Tanna_CV.pdf` and link it:

- [Download CV (PDF)](/assets/Aditya_Tanna_CV.pdf)

**Option B:** Write your resume directly here in Markdown.

## Experience
**Role — Company** (Year–Year)  
- Impact bullet
- Impact bullet

## Skills
- Skill 1, Skill 2, Skill 3
