---
layout: default
title: Projects
permalink: /projects
---

# Projects

## Project Name 1
- What problem it solves
- What you built / contributed
- Tech: X, Y, Z  
Links: [Demo](#) • [Code](#) • [Write-up](#)

## Project Name 2
- One-liner
Links: [Code](#)
