---
layout: default
title: Contact
permalink: /contact
---

# Contact

- Email: <a href="mailto:aditya.tanna@arya.ai">aditya.tanna@arya.ai</a>
- Google Scholar: <a href="https://scholar.google.com/citations?user=8y8sDywAAAAJ&hl=en" target="_blank" rel="noopener">Profile</a>
- LinkedIn: <a href="https://www.linkedin.com/" target="_blank" rel="noopener">Add link</a>
- GitHub: <a href="https://github.com/" target="_blank" rel="noopener">Add link</a>
