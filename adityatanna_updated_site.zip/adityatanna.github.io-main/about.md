---
layout: default
title: About
permalink: /about
---

# About

Write a short bio here (2–4 paragraphs). Good structure:

- What you do now  
- What you’ve done before  
- What you’re interested in / looking for  

## Interests
- Topic 1
- Topic 2
- Topic 3

## Education (optional)
- Degree, University, Year
