---
layout: default
title: Publications
permalink: /publications
---

# Publications

Primary profile: <a href="https://scholar.google.com/citations?user=8y8sDywAAAAJ&hl=en" target="_blank" rel="noopener">Google Scholar</a>

## Selected
<div class="pub">
  <div class="title">Paper Title One</div>
  <div class="meta">Authors • Venue • Year • <a href="#" target="_blank" rel="noopener">PDF</a> • <a href="#" target="_blank" rel="noopener">Code</a></div>
</div>

<div class="pub">
  <div class="title">Paper Title Two</div>
  <div class="meta">Authors • Venue • Year • <a href="#" target="_blank" rel="noopener">PDF</a></div>
</div>

## Full list
<p class="small">
Tip: export BibTeX from Google Scholar and paste entries into a file later — I can help you auto-render them.
</p>
