# Personal website

This site is built with GitHub Pages + Jekyll.

## Local preview (optional)
If you want to run locally:
- Install Ruby + Bundler
- `bundle exec jekyll serve`
